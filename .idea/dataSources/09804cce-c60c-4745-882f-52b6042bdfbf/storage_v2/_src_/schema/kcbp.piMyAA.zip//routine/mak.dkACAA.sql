create function mak() returns int
BEGIN
	#Routine body goes here...
	DECLARE userNum int DEFAULT 1; -- 用户最小编号
	DECLARE userMaxNum int DEFAULT 50; -- 用户最大编号
	DECLARE userIsExists int default 0;


	DECLARE customerNum int DEFAULT 1; -- 用户最小编号
	DECLARE customerMaxNum int DEFAULT 10000; -- 用户最大编号
  DECLARE customerCount int;

	DECLARE loginActStr varchar(1000);
	DECLARE customerId varchar(1000);

	While userNum <= userMaxNum DO
			
			if userNum <10 then 
					set loginActStr = concat('test00',userNum);					
			elseif  userNum <100  then
				set loginActStr = concat('test0',userNum);
			ELSEif userNum <1000  then
					set loginActStr = concat('test',userNum);				
			end if;


			-- BEGIN 生成user信息					
			select count(1) into  userIsExists from tbl_user where loginAct = loginActStr;
			if  userIsExists = 0 THEN
				insert into tbl_user(loginAct,loginPwd,isLogin,isDaoru) values (loginActStr,'test1234',0,0);
			end if;
			-- end 生成user信息
	

			-- BEGIN 生成customer信息				
			set customerNum = 1;
			select count(1) into customerCount from tbl_customer where loginAct = loginActStr;
			if customerCount < customerMaxNum THEN
				delete from tbl_customer where loginAct = loginActStr;		
			
				while  customerNum <= customerMaxNum DO				
					if customerNum < 10 then 
						set customerId = CONCAT(loginActStr,'-0000');					
					elseif  customerNum < 100  then
						set customerId = CONCAT(loginActStr,'-000');
					ELSEif customerNum < 1000  then
						set customerId = CONCAT(loginActStr,'-00');
					ELSEif customerNum < 10000  then
						set customerId = CONCAT(loginActStr,'-0');
					ELSEif customerNum = 10000  then
						set customerId = CONCAT(loginActStr,'-');
					end if;	

					insert into tbl_customer(customerId,customerName,customerPower,website,phone,empNum,salary,description,loginAct) values (CONCAT(customerId,customerNum),CONCAT(customerId,customerNum),'','http://www.baidu.com','0100-74523145',100,50,'百度一下你就知道',loginActStr);
					
					set customerNum = customerNum +1;
				end while;
				
			end if;
			-- end 生成customer信息

		

			set userNum = userNum +1;
			
	
	END WHILE ;
	
	
	RETURN 0;
END;

